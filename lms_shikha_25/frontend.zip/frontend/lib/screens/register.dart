import 'package:flutter/material.dart';
import '../models/user.dart';
import '../services/user_service.dart';
import '../utils/custom_Alert_box.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  RegisterScreenState createState() => RegisterScreenState();
}

class RegisterScreenState extends State<RegisterScreen> {
  final nameController = TextEditingController();
  final usernameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  void handleRegister() async {
    final user = User(
      id: '',
      name: nameController.text,
      username: usernameController.text,
      email: emailController.text,
      password: passwordController.text,
    );

    final response = await UserService.register(user);

    if (response['message'] == 'User registered successfully') {
      CustomAlertBox.showSuccess(
        context,
        "Success",
        "User registered successfully",
      );
    } else {
      CustomAlertBox.showError(
        context,
        "Error",
        response['message'],
      );
    }

    print(response);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Register"),
      ),
      body: Column(
        children: [
          const Text("This is the register screen."),

          TextField(
            controller: nameController,
            decoration: const InputDecoration(
              labelText: "Name",
              hintText: "Enter your name",
            ),
          ),
          TextField(
            controller: usernameController,
            decoration: const InputDecoration(
              labelText: "Username",
              hintText: "Enter your username",
            ),
          ),
          TextField(
            controller: emailController,
            decoration: const InputDecoration(
              labelText: "Email",
              hintText: "Enter your email",
            ),
          ),
          TextField(
            controller: passwordController,
            decoration: const InputDecoration(
              labelText: "Password",
              hintText: "Enter your password",
            ),
          ),

          TextButton(
            onPressed: handleRegister,
            child: const Text("Register"),
          )
        ],
      ),
    );
  }
}
