import 'package:flutter/material.dart';
import './screens/register.dart';

void main() {
  runApp(MyApp());   // removed const
}

class MyApp extends StatelessWidget {
  MyApp();   // simple constructor without super.key

  
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LMS',
      initialRoute: '/',
      routes: {
        '/': (context) => RegisterScreen(),  // removed const
      },
    );
  }
}
